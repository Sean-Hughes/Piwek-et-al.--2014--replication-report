// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Transmit",
      "url": "backend.php",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "Piwek et al. (2014) Likeness Condition",
    "description": "Pre-registered replication of Piwek et al. Uncanny Valley effect",
    "repository": "https:\u002F\u002Fosf.io\u002F7tr8a\u002F?view_only=f13f35b5e9124b8f9914c0284e95cee4",
    "contributors": "Sean Hughes"
  },
  "messageHandlers": {},
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Form",
      "content": "\u003Cheader\u003E\n    \u003Ch1\u003EInformed Consent\u003C\u002Fh1\u003E\n\u003C\u002Fheader\u003E\n\n\u003Cmain style=\"text-align:left; font-family:Helvetica; font-size: 18pt; margin:1%\"\u003E\n\n\u003Cform id =\"InformedConsent\"\u003E\n        \u003Cp style=\"font-size: 18pt\"\u003E\u003Cb\u003E\u003Cbr\u003E Project Title: IMAGE RATING STUDY \u003C\u002Fb\u003E\u003C\u002Fp\u003E\n\n    \u003Cp style=\"font-size: 16pt\"\u003E\u003Cb\u003EOverview and Procedures:\u003C\u002Fb\u003E\n        The purpose of this study is to examine how people remember and learn new information. During the study you will encounter a number of characters. You will be asked questions about them and about your experiences during the study. \u003C\u002Fp\u003E\n        \n    \u003Cp style=\"font-size: 16pt\"\u003E\u003Cb\u003ERisk and Benefits.\u003C\u002Fb\u003E\n\t\tThis study involves no more risk to your physical or psychological health beyond those encountered in the normal course of everyday life.\n\t\tYou may benefit by gaining a better understanding of psychological research. No other risks or benefits are anticipated.\u003C\u002Fp\u003E\n\n    \u003Cp style=\"font-size: 16pt\"\u003E\u003Cb\u003EConfidentiality.\u003C\u002Fb\u003E\n\t\tAny information obtained in this study will be kept strictly confidential and used solely for research purposes. We do not ask any identifying information and responses will be kept completely anonymous. Your anonymised data will be posted to a public repository for other researchers to make use of.\u003C\u002Fp\u003E\n\n    \u003Cp style=\"font-size: 16pt\"\u003E\u003Cb\u003ECompensation.\u003C\u002Fb\u003E\n       If you complete the full study, you will receive full payment for your participation. If you decide to withdraw from the study before you have completed it (regardless of the reason why) you are entitled to a payment proportionate to the time you actually spent on the study (taking into account the hourly rate). \u003C\u002Fp\u003E\n\n\t\u003Cp style=\"font-size: 16pt\"\u003E\u003Cb\u003EYour Rights.\u003C\u002Fb\u003E\n        Your decision to participate in this research is voluntary. You can withdraw from the study at any time without penalty.\n\t\tYou do not have to answer any questions you do not want to.\u003C\u002Fp\u003E\n\n\t\u003Cp style=\"font-size: 16pt\"\u003E\u003Cb\u003EContact Information. \u003C\u002Fb\u003E\n        If you have any questions or issues with this study please contact the principle investigator (Sean Hughes) at sean.hughes@ugent.be who can review the matter and provide further information.\n\n\u003Cp\u003EYou must be at least 18 years old in order to participate in this study.\u003C\u002Fp\u003E\n\n\u003Cp\u003EPlease indicate below whether you consent to participate in this research study. I declare that:\u003C\u002Fp\u003E\n\n\u003Cli\u003E I have received information about the tasks and questions I will be asked during this research\u003C\u002Fli\u003E \n\u003Cli\u003E My participation to this scientific research is completely voluntarily\u003C\u002Fli\u003E\n\u003Cli\u003E I grant permission to the researcher to store, analyse, and report my results in an anonymous way \u003C\u002Fli\u003E\n\u003Cli\u003E I know that I can end my participation at each moment without having to give a justification \u003C\u002Fli\u003E\n\u003Cli\u003E I know that not participating or ending my participation has no negative consequences for me \u003C\u002Fli\u003E\n\u003Cli\u003E I give permission that my data will be used for further analyses by other researchers after full anonymization \u003C\u002Fli\u003E\n\u003Cli\u003E I know that the Ghent University is the responsible organization for the person data collected during this research. I know that the data protection officer can give me more information about the protection of my personal information. Contact: Hanne Elsen (privacy@ugent.be). \u003C\u002Fli\u003E\n\u003Cli\u003E I know that I can receive a summary of the results of the research on demand. \u003C\u002Fli\u003E\n\u003Cp\u003E\u003C\u002Fp\u003E\n\n\u003Cform id = \"InformedConsent\"\u003E\n  \u003Cinput name = \"agree\" id = \"agree\" type = \"checkbox\" required\u003E\n  \u003Clabel for = \"agree\"\u003EI agree to participate in this study.\u003C\u002Flabel\u003E\n\u003C\u002Fform\u003E\n\n\u003C\u002Fmain\u003E\n\n\u003Cfooter\u003E\n\u003Cbutton type= \"submit\" form = \"InformedConsent\"\u003EContinue\u003C\u002Fbutton\u003E\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Informed Consent"
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "keypress(Space)": "Space"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Welcome + Structure of experiment ",
      "content": "\u003Cheader\u003E\r\n\u003Ch1 style=\"color:blue\"\u003E Welcome to this study!\u003C\u002Fh1\u003E\u003Cbr\u003E\r\n  \u003C\u002Fheader\u003E\r\n\r\n\u003Cmain class=\"fullscreen\" style=\"padding-bottom:2pt\"\u003E\r\n\u003Cp style=\"text-align:left; font-family: Helvetica; font-size: 20pt;margin-left:40pt;margin-right:50pt\"\u003EBefore we begin please do the following:\r\n\r\n\u003Cul style= \"text-align:left; font-family: Helvetica; font-size: 20pt; line-height: 150%\"\u003E\r\n\u003Cli\u003E \u003Cstrong\u003E Please maximize your browser window now \u003C\u002Fstrong\u003E so that it fills your entire screen \u003C\u002Fli\u003E\r\n\u003Cli\u003E Switch off your phone\u002Fe-mail\u002Fmusic & anything else distracting \u003C\u002Fli\u003E\r\n\u003Cli\u003E Please have your Prolific ID ready (It can be found in your account info)\u003C\u002Fli\u003E  \r\n\u003C\u002Ful\u003E\r\n\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Ch4\u003E\u003Cb\u003E Press the \u003Ckbd\u003E spacebar \u003C\u002Fkbd\u003E to continue \u003C\u002Fb\u003E\u003C\u002Fh4\u003E \r\n\u003C\u002Ffooter\u003E "
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "keypress(Space)": "Space"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Guidelines",
      "content": "\u003Cheader\u003E\r\n\u003Ch1 style=\"color:blue\"\u003ESome Guidelines\u003C\u002Fh1\u003E\u003Cbr\u003E\r\n  \u003C\u002Fheader\u003E\r\n\r\n\u003Cmain\u003E\r\n\u003Cp style=\"text-align:left; font-family: Helvetica; font-size: 20pt;margin-left:40pt;margin-right:50pt;line-height: 150%\"\u003E Make sure you do this experiment on a laptop or regular desktop computer and \u003Cstrong\u003E NOT \u003C\u002Fstrong\u003E on a smartphone or tablet. You will need a keyboard for this experiment. \r\n\u003Cbr\u003E\r\n\r\n\u003Cbr\u003EDo not close this tab and do not switch to other tabs during the experiment. It is important that you \u003Cb\u003Eremain attentive\u003C\u002Fb\u003E. In this way you help us to make this research valuable.\r\n\r\n\u003Cbr\u003E\u003Cbr\u003ESometimes you will have to scroll down to see the end of the page. For example, on this page, you must scroll down to see that you need to press the space bar to continue. \u003C\u002Fp\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Ch4\u003E\u003Cb\u003E Press the \u003Ckbd\u003E spacebar \u003C\u002Fkbd\u003E to continue.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \r\n\u003C\u002Ffooter\u003E "
    },
    {
      "type": "lab.html.Form",
      "content": "  \u003Cheader\u003E\u003Ch2 style=\"color:blue\"\u003E Prolific ID \u003C\u002Fh2\u003E\u003C\u002Fheader\u003E\n\n   \u003Cmain class=\"fullscreen\" style=\"padding-bottom:2pt\"\u003E\n  \u003C!-- ask 1 question: ID --\u003E\n      \n      \u003Cform id =\"Prolific ID\" required\u003E\n        \u003Ctable\u003E\n          \u003Ctr\u003E\n            \u003Cth style=\"text-align:left; font-family: Helvetica; font-size: 18pt;line-height: 150%\"\u003E\n              \u003Clabel for=\"prolific ID\"\u003E 1. Please enter your Prolific ID number below. If you do not have it please retrieve it now. Otherwise you cannot be paid. \u003C\u002Flabel\u003E\n                \u003Cinput name=\"prolific ID\" id=\"prolific ID\" required type=\"text\" cols=\"10\" style=\"width:500pt; height:50pt;\"\u003E\n          \u003C\u002Fth\u003E\n           \u003C\u002Ftr\u003E\n        \u003C\u002Ftable\u003E\n      \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Press this \u003Cbutton type=\"submit\" form=\"Prolific ID\"\u003E button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Prolific ID"
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n  \u003Cimg src=\"static\u002FIntroduction.jpg\" height = \"80%\" width=\"80%\" class=\"center\"\u003E\n\u003C\u002Fheader\u003E\n\n   \u003Cmain class=\"fullscreen\" style=\"padding-bottom:2pt\"\u003E\n  \u003C!-- ask 1 question: ID --\u003E\n      \n      \u003Cform id =\"Part 1\"\u003E\n      \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Press this \u003Cbutton type=\"submit\" form=\"Part 1\"\u003E button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Introduction"
    },
    {
      "type": "lab.html.Form",
      "content": "\n\u003Cheader\u003E\n  \u003Cimg src=\"static\u002FPart_1.jpg\" height = \"45%\" width=\"45%\" class=\"center\"\u003E\n\u003C\u002Fheader\u003E\n\n\n   \u003Cmain class=\"fullscreen\" style=\"padding-bottom:2pt\"\u003E\n  \u003C!-- ask 1 question: ID --\u003E\n      \n      \u003Cform id =\"Part 1\"\u003E\n      \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Press this \u003Cbutton type=\"submit\" form=\"Part 1\"\u003E button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Part 1 "
    },
    {
      "type": "lab.html.Form",
      "content": "  \u003Cheader\u003E\u003Ch2 style=\"color:blue\"\u003E Demographic information \u003C\u002Fh2\u003E\u003C\u002Fheader\u003E\n\n  \u003Cstyle\u003E \n    td:not(:first-child) {\n    padding-top:25pt;\n    padding-bottom:25pt;\n    }\n  \u003C\u002Fstyle\u003E \n\n \u003Cmain class=\"fullscreen\"\u003E\n   \u003C!-- ask 3 questions: age, gender, education --\u003E\n      \n    \u003Cform id =\"Demographics\" required\u003E\n      \u003Ctable\u003E\n        \u003Ctr\u003E\n          \u003Cth style=\"text-align:left; font-family: Helvetica; font-size: 18pt;\"\u003E\n              \u003Clabel for=\"age\"\u003EQ1. What is your age?\u003C\u002Flabel\u003E\n          \u003C\u002Fth\u003E\n          \u003Ctd style=\"text-align:left; font-family: Helvetica; font-size: 18pt;line-height: 150%\"\u003E\n            \u003Cinput name=\"age\" type=\"number\" id=\"age\" required min=\"18\" max = \"70\"\u003E\n          \u003C\u002Ftd\u003E\n        \u003C\u002Ftr\u003E\n        \u003Ctr\u003E\n          \u003Cth style=\"text-align:left; font-family: Helvetica; font-size: 18pt;\"\u003E\n             \u003Clabel for=\"gender\"\u003EQ2. What is your gender? \u003C\u002Flabel\u003E\n          \u003C\u002Fth\u003E\n          \u003Ctd style=\"text-align:left; font-family: Helvetica; font-size: 18pt;line-height: 150%; padding-bottom: 5pt\"\u003E\n              \u003Cselect name=\"gender\" id=\"gender\" required\u003E\n                \u003Coption value=\"\"\u003E ----- \u003C\u002Foption\u003E\n                \u003Coption value=\"male\"\u003E Man \u003C\u002Foption\u003E\n                \u003Coption value=\"female\"\u003E Woman \u003C\u002Foption\u003E\n                \u003Coption value=\"Non-binary\"\u003E Non-binary \u003C\u002Foption\u003E\n                \u003Coption value=\"Prefer not to disclose\"\u003E Prefer not to disclose \u003C\u002Foption\u003E\n                \u003Coption value=\"Prefer to self-discribe\"\u003E Prefer to self-describe (use textbox to do so) \u003C\u002Foption\u003E\n                \u003C\u002Fselect\u003E \n                \u003Cinput name=\"Gender (self-describe)\" id=\"Gender (self-describe)\"cols=\"5\" style=\"width:400pt; height:25pt\"\u003E\n          \u003C\u002Ftd\u003E\n        \u003C\u002Ftr\u003E\n        \u003C\u002Ftable\u003E\n      \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Press this \u003Cbutton type=\"submit\" form=\"Demographics\"\u003E button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Demographics"
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cheader\u003E\n  \u003Cimg src=\"static\u002FPart_2.jpg\" height = \"45%\" width=\"45%\"\u003E\n\u003C\u002Fheader\u003E\n\n   \u003Cmain class=\"fullscreen\" style=\"padding-bottom:2pt\"\u003E\n  \u003C!-- ask 1 question: ID --\u003E\n      \n      \u003Cform id =\"Part 2\"\u003E\n      \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Press this \u003Cbutton type=\"submit\" form=\"Part 2\"\u003E button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Part 2"
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Human_Likeness_Static_Ratings",
      "content": [
        {
          "type": "lab.html.Screen",
          "files": {},
          "responses": {
            "keypress(Space)": "Space"
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Instructions",
          "content": "\u003Cheader\u003E\r\n\u003Ch1 style=\"color:blue\"\u003EInstructions: Please read carefully\u003C\u002Fh1\u003E\u003Cbr\u003E\r\n  \u003C\u002Fheader\u003E\r\n\r\n\u003Cmain\u003E\r\n\u003Cp style=\"text-align:left; font-family: Helvetica; font-size: 20pt;margin-left:40pt;margin-right:50pt;line-height: 150%\"\u003E A series of characters will appear onscreen one at a time. Please indicate how similar you think each character is to a human. \u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align:left; font-family: Helvetica; font-size: 20pt;margin-left:40pt;margin-right:50pt;line-height: 150%\"\u003E Please pay careful attention at all times. \u003C\u002Fp\u003E \r\n\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003Cbr\u003E\r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter style =\" font-family: Helvetica; font-size: 18pt; content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Ch4\u003E\u003Cb\u003E Press the \u003Ckbd\u003E spacebar \u003C\u002Fkbd\u003E to continue.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \r\n\u003C\u002Ffooter\u003E "
        },
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Human_Likeness_Condition",
          "shuffle": true,
          "content": [
            {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Likeness_Ratings",
              "shuffle": true,
              "content": [
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FBattle0_2 01.png\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_Battle_Robot\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_Battle_Robot\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_Battle_Robot"
                },
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FHiMan0_2 01.png\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_High_Man\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_High_Man\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_High_Man"
                },
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FMannequin0_2 01.png\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_Mannequin\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_Mannequin\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_Mannequin"
                },
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FLoMan0_2 01.png\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_Lo_Man\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_Lo_Man\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_Lo_Man"
                },
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FSkeleton0_2 01.png\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_Skeleton\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_Skeleton\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_Skeleton"
                },
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FKlank0_2 01.png\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_Toy_Robot\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_Toy_Robot\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_Toy_Robot"
                },
                {
                  "type": "lab.html.Form",
                  "content": "\u003Chead\u003E\n  \u003Cstyle type=\"text\u002Fcss\"\u003E\n    #likert { text-align:center; }\n    #likert td { width: 15%; }\n   \u003C\u002Fstyle\u003E\n\u003C\u002Fhead\u003E\n \n\u003Cheader style = \"top:110pt;left:110pt\"\u003E\n\u003Cimg src=\"static\u002FZombie0_2 01.png\t\" width=\"280pt\"\u003E\n  \u003C\u002Fheader \u003E\n\n\u003Cmain\u003E\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:20pt;\"\u003E\n   \u003Cstrong style=\"font-size:20pt;\"\u003EPlease rate, using the scale below, how similar this character is to a human. \u003C\u002Fstrong\u003E\n    \u003Cform id =\"Likeness_Zombie\" required\u003E\n      \n      \u003Cp\u003E\u003Cstrong\u003E1 (Very Non-Humanlike) to 9 (Very Humanlike)\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n  \n      \u003Ctable style=\"width:50%; margin-left:auto; margin-right:auto\"\u003E\n    \u003Ctr\u003E\n    \u003Cth\u003E1\u003C\u002Fth\u003E\n    \u003Cth\u003E2\u003C\u002Fth\u003E \n    \u003Cth\u003E3\u003C\u002Fth\u003E\n    \u003Cth\u003E4\u003C\u002Fth\u003E\n    \u003Cth\u003E5\u003C\u002Fth\u003E\n    \u003Cth\u003E6\u003C\u002Fth\u003E\n    \u003Cth\u003E7\u003C\u002Fth\u003E\n    \u003Cth\u003E8\u003C\u002Fth\u003E \n    \u003Cth\u003E9\u003C\u002Fth\u003E    \n  \u003C\u002Ftr\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"1\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"2\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"3\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"4\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"5\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"6\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"7\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"8\" required\u003E\u003C\u002Ftd\u003E\n         \u003Ctd\u003E\u003Cinput type=\"radio\" name=\"likeness_rating\" value=\"9\" required\u003E\u003C\u002Ftd\u003E\n    \u003C\u002Ftr\u003E\n\u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Please click on this \u003Cbutton type=\"submit\" form=\"Likeness_Zombie\"\u003E Submit \u003C\u002Fbutton\u003E button to continue.\n\u003C\u002Ffooter\u003E",
                  "scrollTop": true,
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Likeness_Zombie"
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cheader\u003E\n  \u003Cimg src=\"static\u002FPart_3.jpg\" height = \"45%\" width=\"45%\"\u003E\n\u003C\u002Fheader\u003E\n\n   \u003Cmain class=\"fullscreen\" style=\"padding-bottom:2pt\"\u003E\n  \u003C!-- ask 1 question: ID --\u003E\n      \n      \u003Cform id =\"Part 3\"\u003E\n      \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:17pt\"\u003E\n    Press this \u003Cbutton type=\"submit\" form=\"Part 3\"\u003E button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Part 3"
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cheader\u003E\n    \u003Ch1\u003EDid you encounter any issues with this study?\u003C\u002Fh1\u003E\n\u003C\u002Fheader\u003E\n\n\u003Cmain style=\"text-align:left; font-family:Helvetica; font-size: 18pt; margin:1%\"\u003E\n\n\u003Cform id =\"Issues_with_Study\"\u003E\n    \u003Cdiv style=\" text-align:left color:rgb(20,20,100); font-size:19pt\"\u003E\n     \u003Cp\u003EDid you encounter any problems during this study? For instance, could you see everything OK and did all the response options work for you? \u003C\u002Fp\u003E \n       \n       \u003Cp\u003E If you encountered ANY issues please describe them here. You made it to the end of the experiment, so you will get paid for your time. Telling us about any problems here will not affect your payment at all. But it will help us make the experiment better in the future\u003C\u002Fp\u003E\u003Cbr\u003E\n      \n        \u003Clabel for=\"Issues_with_Study\"\u003EAre there any issues you would like to report (please write 'no issues' if you encountered no problems)?\u003Cbr\u003E\u003Cbr\u003E\u003C\u002Flabel\u003E\n         \n      \n      \u003Ctextarea name = \"Issues_with_Study\" id=\"Issues_with_Study\" size = \"35\" style = \"width: 1000px; height: 250px;\" autocomplete = \"off\" required\u003E\u003C\u002Ftextarea\u003E\n      \n  \u003C\u002Fdiv\u003E\n\u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n\n\u003C!-- submit form to continue --\u003E\n\u003Cfooter style=\"padding:10pt; font-size:18pt;text-align:center;\"\u003E\n    Please click this \u003Cbutton type=\"submit\" form=\"Issues_with_Study\"\u003E Button \u003C\u002Fbutton\u003E in order to continue.\n\u003C\u002Ffooter\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Issues"
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "keypress(Space)": "Space"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Debriefing",
      "content": "\u003Cheader\u003E\r\n\u003Ch1\u003E The study is now complete!\u003C\u002Fh1\u003E\r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Cmain\u003E \r\n    \u003Ch2\u003E Below you will find an overview of what we were trying to investigate in this study. If you are not interested in this, you can immediately press the \u003Ckbd\u003E spacebar \u003C\u002Fkbd\u003E to exit the study.\u003C\u002Fh2\u003E \r\n  \u003Cbr\u003E \r\n  \u003Cbr\u003E \r\n  \u003Cp style=\" text-align:left font-size:19pt\"\u003E So what was this study actually about? In this study we were interested in a phenomenon called the 'uncanny valley'. This refers to an idea that almost but not fully humanlike artificial characters will trigger a profound sense of unease in people (think about creepy robots that look almost human). \r\n  \u003C\u002Fp\u003E \r\n    \r\n  \u003Cp\u003E It's been claimed that moving characters will produce an even stronger 'uncanny valley' effect. Some researchers (Piwek et al. 2014) set out to test this idea and found that it was actually not true (i.e., moving characters produced a smaller uncanny valley effect). So we decided to replicate their work and see if this finding would emerge again.   \r\n \u003Cp\u003E \r\n    \r\n\u003Cp\u003E We assigned participants to two groups. One group were asked how humanlike a number of static characters were (e.g., a picture of a zombie or robot). The second group were either shown static images of characters, or movies where the characters moved in different ways. We then examined if the acceptability of these characters differed depending on whether they were moving or standing still.    \r\n\u003C\u002Fp\u003E\r\n    \r\n    \r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Ch4\u003E\u003Cb\u003E So that is it. We genuinely appreciate the time and effort you put into this experiment. Press the \u003Ckbd\u003E spacebar \u003C\u002Fkbd\u003E to complete the study.\u003C\u002Fb\u003E\u003C\u002Fh4\u003E \r\n\u003C\u002Ffooter\u003E"
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Thank You",
      "content": "\u003C!-- end instruction--\u003E\r\n\u003Cmain class = \"fullscreen\"\u003E\r\n  \u003Cp style=\"color:rgb(20,100,20);font-size:22px;text-align:center\"\u003E \r\n    \u003Cbr\u003E\u003Cbr\u003E\u003Cbold id=\"fb\"\u003E Thank you!\u003C\u002Fbold\u003E\u003Cbr\u003E\r\n  \u003C\u002Fp\u003E\r\n  \u003Cdiv style=\"color:rgb(20,20,100);font-size:18px;text-align:center;padding-left:15vw;padding-right:15vw\"\u003E\r\n    \u003Cp\u003E\r\n     Please click \u003Ca href=\"https:\u002F\u002Fapp.prolific.co\u002Fsubmissions\u002Fcomplete?cc=738B2E28\"\u003Ehere\u003C\u002Fa\u003E to indicate that you finished the study.  \r\n    \u003C\u002Fp\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fmain\u003E"
    }
  ]
})

// Let's go!
study.run()